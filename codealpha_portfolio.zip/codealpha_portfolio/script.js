const themeToggle = document.getElementById("themeToggle");
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const revealElements = document.querySelectorAll(".reveal");
const navAnchors = document.querySelectorAll(".nav-links a");

let savedTheme = localStorage.getItem("portfolioTheme") || "dark";
applyTheme(savedTheme);


themeToggle.addEventListener("click", () => {
  savedTheme = document.body.classList.contains("light") ? "dark" : "light";
  applyTheme(savedTheme);
});

function applyTheme(theme) {
  if (theme === "light") {
    document.body.classList.add("light");
    themeToggle.textContent = "☀️";
  } else {
    document.body.classList.remove("light");
    themeToggle.textContent = "🌙";
  }
  localStorage.setItem("portfolioTheme", theme);
}


menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("show");
});

navAnchors.forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("show");
  });
});


function revealOnScroll() {
  const triggerBottom = window.innerHeight * 0.88;

  revealElements.forEach((el) => {
    const top = el.getBoundingClientRect().top;

    if (top < triggerBottom) {
      el.classList.add("active");
    }
  });
}

window.addEventListener("scroll", revealOnScroll);
window.addEventListener("load", revealOnScroll);